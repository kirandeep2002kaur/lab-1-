import java.util.ArrayList;
/**
 * Customer
 * @version 1.0
 * @since yesterday
 * @author tarn
 * */

public class Customer {
    private String name;
    private double balance;
    ArrayList<Product> listOfProducts=new ArrayList<>();

    /**
     *
     * @param name name of customer
     * @param balance Amount available with the customer
     */
    public Customer(String name, double balance) {
        this.name = name;
        this.balance = balance;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     *
     * @param p Product which you want to buy
     * @return
     */
    public String addToCart(Product p){
        if(this.balance<p.Cost){
            return "Low Balance";
        }else{
            listOfProducts.add(p);
            balance=-p.Cost;
            if(balance<5){
                return "Warning: Low Balance";
            }
            return "Success";
        }
    }

    /**
     * @return Number of product you are buying
     */
    public int displayCart(){
        for(Product p:listOfProducts){
            System.out.println(p.getName());
        }
        return listOfProducts.size();
    }
}

