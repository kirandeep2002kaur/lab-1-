/**
 * Coffee
 * @version 1.0
 * @since yesterday
 * @author tarn
 * */
public class Coffee extends Product{
    private int numOfCream;
    private int numOfSugar;

    /**
     *
     * @param name Name of The Coffee
     * @param numOfCream Amount of Cream you want in your coffee
     * @param numOfSugar Amount of Sugar you want in your coffee
     */

    public Coffee(String name,int numOfCream,int numOfSugar) {

        super(name,1.50);
        this.numOfCream=numOfCream;
        this.numOfSugar=numOfSugar;
    }


    public int getNumOfCream() {
        return numOfCream;
    }

    public void setNumOfCream(int numOfCream) {
        this.numOfCream = numOfCream;
    }

    public int getNumOfSugar() {
        return numOfSugar;
    }

    public void setNumOfSugar(int numOfSugar) {
        this.numOfSugar = numOfSugar;
    }

    /**
     *
     * @param x Amount you can spend for coffee
     * @return
     */
    public static int howManyCoffees(double x){
        int y;
        y= (int) (x%Cost);

        return y;
    }
}
