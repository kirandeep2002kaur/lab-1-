
public abstract class Product {
    protected static double Cost;

    protected String name;

    public Product(String name,double Cost) {
        this.name = name;
        this.Cost=Cost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
