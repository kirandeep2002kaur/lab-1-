
/**
 * Donuts
 * @version 1.0
 * @since yesterday
 * @author tarn
 * */public class Donuts extends Product{
    /**
     *
     * @param name Name of the donut
     */
    public Donuts(String name) {
        super(name,2);
    }

    /**
     *
     * @param x Amount you can spend
     * @return
     */
    public static int howManyDonuts(double x){
        int y;
        y= (int) (x% Cost);

        return y;
    }
}
