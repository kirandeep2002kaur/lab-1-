import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DonutsTest {

    @Test
    void howManyDonuts() {
        Donuts d =new Donuts("Donut");
        assertEquals(4,d.howManyDonuts(8));


    }
}