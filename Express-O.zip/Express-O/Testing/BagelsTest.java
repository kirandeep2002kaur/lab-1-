import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BagelsTest {

    @Test
    void howManyBagels() {
        Bagels b=new Bagels("Bagel",true,true,true);
        assertEquals(2,b.howManyBagels(5));
    }
}