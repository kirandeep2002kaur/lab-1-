import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @org.junit.jupiter.api.Test
    void addToCart() {
        Customer c = new Customer("Tarn",1);
        Donuts d =new Donuts("pineapple");
        assertEquals("Low Balance",c.addToCart(d));
    }

    @org.junit.jupiter.api.Test
    void displayCart() {
        Customer c = new Customer("Tarn",6);
        Donuts d =new Donuts("pineapple");
        c.addToCart(d);
        assertEquals(1,c.displayCart());

    }
}