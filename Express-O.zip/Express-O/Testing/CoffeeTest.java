import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CoffeeTest {

    @Test
    void howManyCoffees() {
        Coffee c = new Coffee("Coffee",2,4);
        assertEquals(2,c.howManyCoffees(3));
    }
}